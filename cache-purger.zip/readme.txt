= Remote Cache Purger =
Contributors: myros
Tags: nginx, cache, purge, kubernetes
Requires at least: 4.7
Tested up to: 5.6
Stable tag: 4.8.1
Requires PHP: 5.6
